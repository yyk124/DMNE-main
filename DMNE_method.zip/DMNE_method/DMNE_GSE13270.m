clear;
clc;
close all;
%%
%����ο������ֲ������ļ�
fpi0=fopen('con_djz.txt');
hline0 = textscan(fpi0, '%s', 1, 'delimiter', '\n');
field0=textscan(hline0{1}{1},'%s');
clear format;
format0='%s';
% format=[format,' %s'];
for i=2:26
    format0=[format0,' %f'];
end
lines0=textscan(fpi0, format0,1000000,'delimiter', '\t');
genename0=lines0{1};
pprofile0 = [];
for i = 2:26
    pprofile0 = [pprofile0, lines0{i}];
end
fclose(fpi0);

fid0=fopen('con_idx.txt');
control_ssn_network={};
j=0;
while ~feof(fid0)
    tline=fgetl(fid0);
    j=j+1;
    control_ssn_network{j}=regexp(tline, '\s+', 'split');
end
fclose(fid0);
total_node_num0=j;
pprofile0=abs(pprofile0);
psize0=size(pprofile0);
%%control
%����ÿ���������������
for na0=1:total_node_num0
     for n0=1:length(control_ssn_network{na0})-1%����������������������center��
        center0=control_ssn_network{na0}{1};
        center0=str2num(center0);
        m_0=mean(pprofile0(center0,1:psize0(2)));
        v_0=std(pprofile0(center0,1:psize0(2)));
        nei0=control_ssn_network{na0}{n0};
        ne0=str2num(nei0);
        m0=mean(pprofile0(ne0,1:psize0(2)));
        v0=std(pprofile0(ne0,1:psize0(2))); 
        for j=1:psize0(2) 
            p0(n0,j)=normpdf(pprofile0(ne0,j),m0,v0);
            p_node0(n0,j)=p0(n0,j)./sum(p0(n0,:));  
            entropy_node0(na0,n0)=-sum(pprofile0(ne0,j).*p_node0(n0,j).*log(abs(pprofile0(ne0,j).*p_node0(n0,j))));
            entropy_code0(na0)=mean(entropy_node0(na0,:));
        end
     end
     entropy0=mean(entropy_code0(:));
end

%%
%%stageI
%����case/adj_network_idx�ļ�
fpi1=fopen('1_djz.txt');
hline1 = textscan(fpi1, '%s', 1, 'delimiter', '\n');
field1=textscan(hline1{1}{1},'%s');
clear format;
format1='%s';
% format1=[format1,' %s'];
for i=2:31
    format1=[format1,' %f'];
end
lines1 =textscan(fpi1, format1,1000000,'delimiter', '\t');
genename1=lines1{1};
pprofile1 = [];
for i = 2:31
    pprofile1 = [pprofile1, lines1{i}];
end
fclose(fpi1);
fid1=fopen('1_idx.txt');
stageI_ssn_network={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    stageI_ssn_network{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
total_node_num1=j;
pprofile1=abs(pprofile1);
psize1=size(pprofile1);
%%stageI
%����ÿ���������������
for na1=1:total_node_num1
     for n1=1:length(stageI_ssn_network{na1})-1%����������������
        center1=stageI_ssn_network{na1}{1};
        center1=str2num(center1);
        m_1=mean(pprofile1(center1,1:psize1(2)));
        v_1=std(pprofile1(center1,1:psize1(2)));
        nei1=stageI_ssn_network{na1}{n1};
        ne1=str2num(nei1);
        m1=mean(pprofile1(ne1,1:psize1(2)));
        v1=std(pprofile1(ne1,1:psize1(2)));
         for j=1:psize1(2) 
            p1(n1,j)=normpdf(pprofile1(ne1,j),m1,v1);
            p_node1(n1,j)=p1(n1,j)./sum(p1(n1,:));  
            entropy_node1(na1,n1)=-sum(pprofile1(ne1,j).*p_node1(n1,j).*log(abs(pprofile1(ne1,j).*p_node1(n1,j))));
            entropy_code1(na1)=mean(entropy_node1(na1,:));
         end
     end
     entropy1=mean(entropy_code1(:));
end
H1=entropy1-entropy0;

%%
%%stageII
%����case/adj_network_idx�ļ�
fpi2=fopen('2_djz.txt');
hline2 = textscan(fpi2, '%s', 1, 'delimiter', '\n');
field2=textscan(hline2{1}{1},'%s');
clear format2;
format2='%s';
% format2=[format2,' %s'];
for i=2:31
    format2=[format2,' %f'];
end
lines2=textscan(fpi2, format2,1000000,'delimiter', '\t');
genename2=lines2{1};
pprofile2= [];
for i = 2 : 31
    pprofile2 = [pprofile2, lines2{i}];
end
fclose(fpi2);
fid2=fopen('2_idx.txt');
stageII_ssn_network={};
j=0;
while ~feof(fid2)
    tline2=fgetl(fid2);
    j=j+1;
    stageII_ssn_network{j}=regexp(tline2, '\s+', 'split');
end
fclose(fid2);
total_node_num2=j;
pprofile2=abs(pprofile2);
psize2=size(pprofile2);
%%stageII
%����ÿ���������������
for na2=1:total_node_num2     
     for n2=1:length(stageII_ssn_network{na2})-1%����������������
        center2=stageII_ssn_network{na2}{1};
        center2=str2num(center2);
        m_2=mean(pprofile2(center2,1:psize2(2)));
        v_2=std(pprofile2(center2,1:psize2(2)));
        nei2=stageII_ssn_network{na2}{n2};
        ne2=str2num(nei2);
        m2=mean(pprofile2(ne2,1:psize2(2)));
        v2=std(pprofile2(ne2,1:psize2(2)));
       for j=1:psize2(2) 
            p2(n2,j)=normpdf(pprofile2(ne2,j),m2,v2);
            p_node2(n2,j)=p2(n2,j)./sum(p2(n2,:));  
            entropy_node2(na2,n2)=-sum(pprofile2(ne2,j).*p_node2(n2,j).*log(abs(pprofile2(ne2,j).*p_node2(n2,j))));
            entropy_code2(na2)=mean(entropy_node2(na2,:));
         end
     end
     entropy2=mean(entropy_code2(:));
end
H2=entropy2-entropy0;

%%
%%stageIII
%����case/adj_network_idx�ļ�
fpi3=fopen('3_djz.txt');
hline3= textscan(fpi3, '%s', 1, 'delimiter', '\n');
field3=textscan(hline3{1}{1},'%s');
clear format3;
format3='%s';
% format3=[format3,' %s'];
for i=2:31
    format3=[format3,' %f'];
end
lines3=textscan(fpi3, format3,1000000,'delimiter', '\t');
genename3=lines3{1};
pprofile3= [];
for i = 2 : 31
    pprofile3= [pprofile3, lines3{i}];
end
fclose(fpi3);
fid3=fopen('3_idx.txt');
stageIII_ssn_network={};
j=0;
while ~feof(fid3)
    tline3=fgetl(fid3);
    j=j+1;
    stageIII_ssn_network{j}=regexp(tline3, '\s+', 'split');
end
fclose(fid3);
total_node_num3=j;
pprofile3=abs(pprofile3);
psize3=size(pprofile3);
%%stageIII
%����ÿ���������������
for na3=1:total_node_num3
     for n3=1:length(stageIII_ssn_network{na3})-1%����������������
        center3=stageIII_ssn_network{na3}{1};
        center3=str2num(center3);
        m_3=mean(pprofile3(center3,1:psize3(2)));
        v_3=std(pprofile3(center3,1:psize3(2)));
        nei3=stageIII_ssn_network{na3}{n3};
        ne3=str2num(nei3);
        m3=mean(pprofile3(ne3,1:psize3(2)));
        v3=std(pprofile3(ne3,1:psize3(2)));
         for j=1:psize3(2) 
            p3(n3,j)=normpdf(pprofile3(ne3,j),m3,v3);
            p_node3(n3,j)=p3(n3,j)./sum(p3(n3,:));  
            entropy_node3(na3,n3)=-sum(pprofile3(ne3,j).*p_node3(n3,j).*log(abs(pprofile3(ne3,j).*p_node3(n3,j))));
            entropy_code3(na3)=mean(entropy_node3(na3,:));
         end
     end
     entropy3=mean(entropy_code3(:));
end
H3=entropy3-entropy0;

%%
%stageIV
fpi4=fopen('4_djz.txt');
hline4 = textscan(fpi4, '%s', 1, 'delimiter', '\n');
field4=textscan(hline4{1}{1},'%s');
clear format4;
format4='%s';
% format4=[format4,' %s'];
for i=2:31
    format4=[format4,' %f'];
end
lines4 =textscan(fpi4, format4,1000000,'delimiter', '\t');
genename4=lines4{1};
pprofile4= [];
for i = 2 :31
    pprofile4 = [pprofile4, lines4{i}];
end
fclose(fpi4);
fid4=fopen('4_idx.txt');
stageIV_ssn_network={};
j=0;
while ~feof(fid4)
    tline4=fgetl(fid4);
    j=j+1;
    stageIV_ssn_network{j}=regexp(tline4, '\s+', 'split');
end
fclose(fid4);
total_node_num4=j;
pprofile4=abs(pprofile4);
psize4=size(pprofile4);
%%stageIV
%����ÿ���������������
for na4=1:total_node_num4
     for n4=1:length(stageIV_ssn_network{na4})-1%����������������
        center4=stageIV_ssn_network{na4}{1};
        center4=str2num(center4);
        m_4=mean(pprofile4(center4,1:psize4(2)));
        v_4=std(pprofile4(center4,1:psize4(2)));
        nei4=stageIV_ssn_network{na4}{n4};
        ne4=str2num(nei4);
        m4=mean(pprofile4(ne4,1:psize4(2)));
        v4=std(pprofile4(ne4,1:psize4(2)));
        for j=1:psize4(2) 
            p4(n4,j)=normpdf(pprofile4(ne4,j),m4,v4);
            p_node4(n4,j)=p4(n4,j)./sum(p4(n4,:));  
            entropy_node4(na4,n4)=-sum(pprofile4(ne4,j).*p_node4(n4,j).*log(abs(pprofile4(ne4,j).*p_node4(n4,j))));
            entropy_code4(na4)=mean(entropy_node4(na4,:));
         end
     end
     entropy4=mean(entropy_code4(:));
end
H4=entropy4-entropy0;

%%
%%stageV
fpi5=fopen('5_djz.txt');
hline5 = textscan(fpi5, '%s', 1, 'delimiter', '\n');
field5=textscan(hline5{1}{1},'%s');
clear format5;
format5='%s';
% format5=[format5,' %s'];
for i=2:31
    format5=[format5,' %f'];
end
lines5=textscan(fpi5, format5,1000000,'delimiter', '\t');
genename5=lines5{1};
pprofile5= [];
for i = 2 :31
    pprofile5 = [pprofile5, lines5{i}];
end
fclose(fpi5);
fid5=fopen('5_idx.txt');
stageV_ssn_network={};
j=0;
while ~feof(fid5)
    tline5=fgetl(fid5);
    j=j+1;
    stageV_ssn_network{j}=regexp(tline5, '\s+', 'split');
end
fclose(fid5);
total_node_num5=j;
pprofile5=abs(pprofile5);
psize5=size(pprofile5);
%%stageV
%����ÿ���������������
for na5=1:total_node_num5
     for n5=1:length(stageV_ssn_network{na5})-1%����������������
        center5=stageV_ssn_network{na5}{1};
        center5=str2num(center5);
        m_5=mean(pprofile5(center5,1:psize5(2)));
        v_5=std(pprofile5(center5,1:psize5(2)));
        nei5=stageV_ssn_network{na5}{n5};
        ne5=str2num(nei5);
        m5=mean(pprofile5(ne5,1:psize5(2)));
        v5=std(pprofile5(ne5,1:psize5(2)));
         for j=1:psize5(2) 
            p5(n5,j)=normpdf(pprofile5(ne5,j),m5,v5);
            p_node5(n5,j)=p5(n5,j)./sum(p5(n5,:));  
            entropy_node5(na5,n5)=-sum(pprofile5(ne5,j).*p_node5(n5,j).*log(abs(pprofile5(ne5,j).*p_node5(n5,j))));
            entropy_code5(na5)=mean(entropy_node5(na5,:));
         end
     end
     entropy5=mean(entropy_code5(:));
end
H5=entropy5-entropy0;

%%
figure('NumberTitle', 'off', 'Name', 'Disturbance Information Gain');
A=[H1,H2,H3,H4,H5];
D=zscore(A);
plot((1:5),D,'r','LineWidth',3);
set(gca,'XTick',1:5);
B={'4week' '8week' '12week'  '16week' '20week'};
set(gca,'XTickLabel',B);
xlabel('Stage');
ylabel('score');
title('The different flow entropy of GSE13270');

%%
xlswrite('genename4.xlsx',genename1);
xlswrite('genename8.xlsx',genename2);
xlswrite('genename12.xlsx',genename3);
xlswrite('genename16.xlsx',genename4);
xlswrite('genename20.xlsx',genename5);
xlswrite('MI_sum4.xlsx',entropy_code1);
xlswrite('MI_sum8.xlsx',entropy_code2);
xlswrite('MI_sum12.xlsx',entropy_code3);
xlswrite('MI_sum16.xlsx',entropy_code4);
xlswrite('MI_sum20.xlsx',entropy_code5);

%%
fpi1=fopen('DNB.txt');
hline1 = textscan(fpi1, '%s', 1, 'delimiter', '\n');
field1=textscan(hline1{1}{1},'%s');
clear format;
format1='%s';
% format1=[format1,' %s'];
for i=2:6
    format1=[format1,' %f'];
end
lines1 =textscan(fpi1, format1,1000000,'delimiter', '\t');
genename0=lines1{1};
pprofile0 = [];
for i = 2 :6
    pprofile0 = [pprofile0, lines1{i}];
end
fclose(fpi1);
psize=size(pprofile0);
figure('NumberTitle', 'off', 'Name','The G-score landscape of DNB');
surf([1:size(pprofile0,2)],[1:size(pprofile0,1)],pprofile0);
set(gca,'XTick',1:5);
B={'4week' '8week' '12week'  '16week' '20week'};
set(gca,'XTickLabel',B);
xlabel('stage');
ylabel('Genes');
zlabel('TNFE-score')
title(' The landscapes of DNB for GSE13270');
shading interp;