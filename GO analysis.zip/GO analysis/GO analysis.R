install.packages(‘package name’)

library(dplyr)
library(readr)
library(tidyverse)
emapper <- read_delim("C:/Users/86166/Desktop/Fuji/11.txt", 
                      delim = "\t", escape_double = FALSE, 
                      col_names = FALSE, trim_ws = TRUE) %>%
  dplyr::select(GID = X1, 
                symple = X2, 
                BP = X3,
                CC = X4,
                MF = X5) 



CC <- dplyr::select(emapper, GID, symple, CC) %>%   
  separate_rows(CC, sep = '//', convert = F)      


write.table(CC,file = "C:/Users/86166/Desktop/Fuji/CC.txt", sep = "\t")  


library(clusterProfiler)
library(dplyr)
library(readr)

GSE13270 <- read_delim("C:/Users/86166/Desktop/Fuji/GSE13270.txt", 
                       delim = "\t", escape_double = FALSE, 
                       trim_ws = TRUE)
target_gene <- as.character((GSE13270$`16 weeks`))


emapper <- read_delim("C:/Users/86166/Desktop/Fuji/GO.txt", 
                      delim = "\t", escape_double = FALSE, 
                      col_names = FALSE, trim_ws = TRUE) %>%
  dplyr::select(GID= X2,
                GO = X3,
                term = X4)

GO2gene <- dplyr::select(emapper, GO, GID)
GO2des <- dplyr::select(emapper, GO, term)

enrich_res <-  enricher(target_gene, 
                        TERM2GENE = GO2gene, 
                        TERM2NAME = GO2des, 
                        pvalueCutoff=1, 
                        pAdjustMethod = "BH",
                        qvalueCutoff=1,
                        minGSSize = 1, 
                        maxGSSize = 800000)


enrich <- as.data.frame(enrich_res)    


write.table(enrich_res, file="C:/Users/86166/Desktop/Fuji/GSE13270_16weeks.csv", 
            col.names= T, 
            row.names= F,
            sep=",", 
            quote=F)


## -----------------------------------------------------------
#'showCategory':Displays the top 10 pathways
barplot(enrich_res, showCategory = 10)

## -----------------------------------------------------------
dotplot(enrich_res, showCategory =10)


## -----------------------------------------------------------
cnetplot(enrich_res, 
         #foldChange = geneList, 
         showCategory = 3,
         node_label = "gene", # category | gene | all | none
         #circular = TRUE, 
         colorEdge = TRUE)

cnetplot(enrich_res, 
         #foldChange = geneList,
         showCategory = 4,
         node_label = "gene", # category | gene | all | none
         circular = TRUE, 
         colorEdge = TRUE)   

library(enrichplot)
x2 <- pairwise_termsim(enrich_res)
emapplot(x2, showCategory = 60, pie = 'count')