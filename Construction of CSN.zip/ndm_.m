clear
data=xlsread('D:\MATBLE2017b\bin\cs\GSE13268.xlsx');
 alpha = 0.01;
normalize = 1;
boxsize = 0.1;

ndm = csndm(data,alpha,boxsize,normalize);
xlswrite('E:\GSE13268-69-70\ndm_GSE13268.xlsx',ndm)


