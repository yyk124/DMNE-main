clear
data=xlsread('D:\MATBLE2017b\bin\cs\GSE13268case11.xlsx');
c=[];
alpha=0.01;
boxsize=0.1;
weighted=0;
csn = csnet(data,c,alpha,boxsize,weighted);