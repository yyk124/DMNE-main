data = zeros(15320);
for i = 1:length(csn)
    tmp = csn{1,i};
    data = data + tmp;   
end
avr = data/length(csn);
csvwrite('E:\GSE13268-69-70\average_GSE13268control.csv',avr)





